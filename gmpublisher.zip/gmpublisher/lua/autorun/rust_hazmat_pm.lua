player_manager.AddValidModel( "Rust Hazmat Suit", "models/player/darky_m/rust/hazmat.mdl" )
list.Set( "PlayerOptionsModel", "Rust Hazmat Suit", "models/player/darky_m/rust/hazmat.mdl" )
player_manager.AddValidHands( "Rust Hazmat Suit", "models/player/darky_m/rust/hazmat_arms.mdl", 0, "00000000" )